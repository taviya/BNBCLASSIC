export const contract = { 
    // 97 : {
    //     tokenAddress : "0xa14382a519bc744f422b1e90be04edd23a519821",
    //     saleAddress : "0x7de20878a51a6210918c63d66e59f93ac51166e5",
    //     multicallAddress : "0xa54fe4a3dbd1eb21524cd73754666b7e13b4cb18"
    // },
    56 : {
        saleAddress : "0x738386b9364da9907f139a60cadbd8d64768e26f",
        multicallAddress : "0x2cc8fe3e04d7b1edaeb42e2e73f78c4cac074116"
    },
    'default':{
        saleAddress : "0x738386b9364da9907f139a60cadbd8d64768e26f",
        multicallAddress : "0x2cc8fe3e04d7b1edaeb42e2e73f78c4cac074116"
    }

}

